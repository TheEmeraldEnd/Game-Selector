using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting.FullSerializer;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to get and organize the data of the UI
    /// </summary>
    public static class UIDataStatic
    {
        #region Game Path Editing Data
        /// <summary>
        /// Get the name input field reference with the input
        /// </summary>
        private static NameInputField _nameInputFieldRef;
        private static NameInputField NameInputFieldRef
        {
            get
            {
                if (_nameInputFieldRef == null)
                    _nameInputFieldRef = GameObject.FindObjectOfType<NameInputField>();

                return _nameInputFieldRef;
            }
        }

        /// <summary>
        /// The input of the path
        /// </summary>
        private static PathInputField _pathInputFieldRef;
        private static PathInputField PathInputFieldRef
        {
            get
            {
                if (_pathInputFieldRef == null)
                    _pathInputFieldRef = GameObject.FindObjectOfType<PathInputField>();

                return _pathInputFieldRef;
            }
        }

        /// <summary>
        /// Get the temporary name input
        /// </summary>
        public static string TempNameInput
        {
            get { return NameInputFieldRef.InputText; }
            set { NameInputFieldRef.InputText = value;}
        }

        /// <summary>
        /// The temporary path input that hasn't been confirmed yet
        /// </summary>
        public static string TempPathInput
        {
            get { return PathInputFieldRef.InputText; }
            set {  PathInputFieldRef.InputText = value;}
        }

        /// <summary>
        /// Used to set the temporary game data
        /// </summary>
        public static GameData TempGameData
        {
            get
            {
                GameData tempGameData = new();
                tempGameData.GameName = TempNameInput;
                tempGameData.ExecutablePath = TempPathInput;
                return tempGameData;
            }
        }

        /// <summary>
        /// Clears the data of the temp game editor
        /// </summary>
        public static void ClearNewGameEditor()
        {
            PathInputFieldRef.InputText = "";
            NameInputFieldRef.InputText = "";
        }
        #endregion

        /// <summary>
        /// Sets the temp game data to list without saving the list
        /// </summary>
        public static void SetTempToList()
        {
            GameDataAccessorStatic.AddGameDataToList(TempGameData);
        }

        #region Deleting Data
        private static DeletableGamePathsDropDown _deletableGameDropDownRef;
        private static DeletableGamePathsDropDown DeletableGameDropDownRef
        {
            get
            {
                if ( _deletableGameDropDownRef == null )
                    _deletableGameDropDownRef = GameObject.FindObjectOfType<DeletableGamePathsDropDown>();

                return _deletableGameDropDownRef;
            }
        }

        /// <summary>
        /// REturns the game data of the deletable game data
        /// </summary>
        /// <returns></returns>
        public static GameData SelectedDeletableGameData()
        {
            string gameNameOption = DeletableGameDropDownRef.SelectedGameName;

            foreach(var gameData in GameDataAccessorStatic.GameData)
            {
                if ( gameData.GameName == gameNameOption)
                {
                    return gameData;
                }
                    
            }

            return new();
        }

        /// <summary>
        /// Deletes the selected game
        /// </summary>
        public static void DeleteSelectedGameData()
        {
            GameDataAccessorStatic.DeleteGame(SelectedDeletableGameData());
        }
        #endregion

        /// <summary>
        /// Saves the list of the changes to the text file
        /// </summary>
        public static void SaveListChanges()
        {
            string[] gameDatas = GameDataAccessorStatic
                                .GameData
                                .Select(g => g.ToString())
                                .ToArray();

            string pathway = UnityFileAccessorStatic.CompleteGameExecutablesTextPath;

            UnityFileAccessorStatic.WriteLinesToTextFile(pathway, gameDatas);
        }

    }
}