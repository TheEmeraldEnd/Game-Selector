using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to delete the selected game
    /// </summary>
    public class DeleteSelectedGameButton : ButtonComponentBase
    {
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            UIDataStatic.DeleteSelectedGameData();
        }
    }
}

