using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GlobalScripts;
using Unity.VisualScripting;

namespace GamePathListEditor
{
    /// <summary>
    /// Updates the dropdown selector if the selector changes
    /// </summary>
    public class GameDropDownUpdater : DropDownComponentBase
    {
        #region count data
        [Header("Count Data")]

        [Tooltip("")]
        [SerializeField]
        private int _lastUpdateGameCounter = 0;
        #endregion

        private void Update()
        {
            int stuff = GameDataAccessorStatic.GameData.Length;

            if (_lastUpdateGameCounter != 
                GameDataAccessorStatic.GameData.Length)
            {
                string[] options = GameDataAccessorStatic.GetGameNames();
                SetOptionTexts(options);
            }

            if (GameDataAccessorStatic.GameData.Length == 0)
            {
                string[] options = new string[0];
                SetOptionTexts(options);
            }
                
            _lastUpdateGameCounter = GameDataAccessorStatic.GameData.Length;
        }
    }
}

