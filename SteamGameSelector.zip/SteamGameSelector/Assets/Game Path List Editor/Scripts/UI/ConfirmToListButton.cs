using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to confirm the choices to the 
    /// </summary>
    public class ConfirmToListButton : ButtonComponentBase
    {
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            UIDataStatic.SetTempToList();
            UIDataStatic.ClearNewGameEditor();
        }
    }
}

