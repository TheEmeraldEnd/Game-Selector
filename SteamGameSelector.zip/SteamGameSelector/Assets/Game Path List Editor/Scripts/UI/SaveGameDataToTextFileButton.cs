using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Saves the game list data to the text file
    /// </summary>
    public class SaveGameDataToTextFileButton : ButtonComponentBase
    {
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            UIDataStatic.SaveListChanges();
        }
    }
}

