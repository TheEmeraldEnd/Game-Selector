using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace PlayerControllerScene
{
    public class ToSceneInteractable : MonoBehaviour, IInteractable
    {
        #region Scene Data
        [Header("Scene Data")]

        [Tooltip("The name of the scene being transported to")]
        [SerializeField]
        private string _sceneName;
        #endregion

        public void IOnInteract()
        {
            SceneManager.LoadScene(_sceneName);
        }
    }
}