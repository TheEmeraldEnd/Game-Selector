using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using PlayerControllerScene;

namespace PlayerControllerScene
{
    /// <summary>
    /// Used to activate whenever the interact button is pressed
    /// </summary>
    public class ActivateInteractablesScript : MonoBehaviour
    {
        #region interactable storage
        [Header("The interactable being stored")]

        [Tooltip("The interactable being stored")]
        [SerializeField]
        private IInteractable _interactable;
        #endregion

        #region Input Methods
        /// <summary>
        /// Activates the interactables that are being collided with
        /// </summary>
        /// <param name="cxt"></param>
        public void ActivateInteractables(InputAction.CallbackContext cxt)
        {
            _interactable.IOnInteract();
        }
        #endregion

        #region Unity Methods
        private void OnTriggerEnter2D(Collider2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = interactable;
        }

        private void OnTriggerExit2D(Collider2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = interactable;
        }
        #endregion
    }
}

