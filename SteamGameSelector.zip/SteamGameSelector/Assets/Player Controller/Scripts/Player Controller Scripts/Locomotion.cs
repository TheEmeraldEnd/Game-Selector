using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using PlayerControllerScene;

namespace PlayerControllerScene
{
    /// <summary>
    /// Sets the velocity of the player based on the controller
    /// </summary>
    public class Locomotion : MonoBehaviour
    {
        #region Speed
        [Header("Speed Related")]

        [Tooltip("Sets how fast the player goes in meters per second")]
        [SerializeField, Min(0f)]
        private float _speedInMetersPerSecond = 1f;
        #endregion

        #region Input Methods
        /// <summary>
        /// Set the velocity of the player
        /// </summary>
        /// <param name="cxt"></param>
        public void SetPlayerDirection(InputAction.CallbackContext cxt)
        {
            Vector2 vectorContext = cxt.ReadValue<Vector2>();

            PlayerDataStatic
                .SetPlayerVelocity(vectorContext * _speedInMetersPerSecond);
        }
        #endregion
    }
}