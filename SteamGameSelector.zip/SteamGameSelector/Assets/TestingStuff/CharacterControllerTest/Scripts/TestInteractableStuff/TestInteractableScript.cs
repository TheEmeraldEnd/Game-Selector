using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    public class TestInteractableScript : TriggerBaseScript, IInteractable
    {
        public void OnInteract()
        {
            print("Interaction Successful");
        }
    }
}

