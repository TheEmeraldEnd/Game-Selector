using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    public class ShowInteractable : TriggerBaseScript
    {
        #region Interactable Sign
        [Header("Interactable game object shower")]

        [Tooltip("The gameobject thast appears whenever the player enters")]
        [SerializeField]
        private GameObject _interactableSign;
        #endregion

        #region Unity Methods
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.tag != "Player")
                return;

            _interactableSign.SetActive(true);
        }

        private void OnTriggerExit2D(Collider2D collision)
        {
            if (collision.tag != "Player")
                return;

            _interactableSign.SetActive(false);
        }
        #endregion
    }

}
