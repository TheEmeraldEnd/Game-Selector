using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

/// <summary>
/// Used whenever there is something that is needed to be interacted with the
///     interact button.
/// </summary>
namespace V0_1
{
    public interface IInteractable
    {
        void OnInteract();
    }
}

