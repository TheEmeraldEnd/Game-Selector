using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to set the movement of a player
    /// </summary>
    public class Locomotion : Rigidbody2DComponent
    {
        #region Togglable Variables
        [Tooltip("How fast the player is moving in meters per second")]
        [SerializeField, Min(0f)]
        private float _speed = 1f;

        [Tooltip("Used to set the tolerance used to cancel movement")]
        [SerializeField, Min(0f)]
        private float _magnitudeTollerance = 0.2f;
        #endregion

        #region Input related
        /// <summary>
        /// Set the velocity
        /// </summary>
        /// <param name="cxt"></param>
        public void SetVelocity(InputAction.CallbackContext cxt)
        {
            //Get the direction of the input
            Vector2 inputDirection = cxt.ReadValue<Vector2>();

            //Check if magnitude threshold is passed and find the direction normalized
            Vector2 direction;
            float magnitude = inputDirection.magnitude;
            if (magnitude <= _magnitudeTollerance)
                direction = Vector2.zero;
            else
                direction = inputDirection.normalized;

            //Apply to the rigidbody
            SetRigidbodyVelocity(direction, _speed);
        }
        #endregion
    }
}

