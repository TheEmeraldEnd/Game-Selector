using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to display the sprite animation when going in different directions
    /// </summary>
    public class SpriteDisplayer : Rigidbody2DComponent
    {
        #region Animator Component
        [Header("Animation Related")]

        [Tooltip("The animator related to changing the animation playing on the player")]
        [SerializeField, HideInInspector]
        private Animator playerAnimator;

        private void InitializeComponent()
        {
            if (playerAnimator == null)
                playerAnimator = GetComponent<Animator>();
        }
        #endregion

        #region OverrideableEvents
        protected override void OverridableOnEnable()
        {
            base.OverridableOnEnable();

            InitializeComponent();
        }
        #endregion

        #region Animation States
        [Header("Last Animation State")]

        [Tooltip("Used to store the last known direction")]
        [SerializeField, HideInInspector]
        private string _lastFrameDirectionAnimation = "South";

        [Tooltip("Used to store if the last animation was moveing or not")]
        [SerializeField, HideInInspector]
        private string _lastFrameSpeedAnimation = "Idle";

        /// <summary>
        /// Determines the direction if used
        /// </summary>
        /// <returns></returns>
        private string DetermineDirection()
        {
            //Get the variables needed to calculate the animation
            Vector2 velocity = GetRigidbodyVelocity();

            //return last known direction if there isn't a direction to go to
            if (velocity.magnitude == 0)
                return _lastFrameDirectionAnimation;

            string tempDirection = "";
            //Get the horizontal direction
            float horizontalValue = velocity.x;
            if (horizontalValue < 0f)
                tempDirection = "West";
            else if (horizontalValue > 0f)
                tempDirection = "East";

            //Get the vertical direction
            float verticalValue = velocity.y;
            if (verticalValue < 0f)
                tempDirection = "South";
            else if (verticalValue > 0f)
                tempDirection = "North";

            return tempDirection;
        }

        /// <summary>
        /// Determines the motion of the animation being played
        /// </summary>
        /// <returns></returns>
        private string DetermineSpeedAnimation()
        {
            float magnitude = GetRigidbodyVelocity().magnitude;

            if (magnitude == 0f)
                return "Idle";
            else
                return "Walking";
        }
        #endregion

        #region Unity Methods
        private void Update()
        {
            //Set up the animation string
            string currentDirection = DetermineDirection();
            string currentSpeed = DetermineSpeedAnimation();
            string animationString = currentSpeed + currentDirection;

            if (animationString != (_lastFrameSpeedAnimation + _lastFrameDirectionAnimation))
                playerAnimator.Play(animationString);

            _lastFrameDirectionAnimation = currentDirection;
            _lastFrameSpeedAnimation = currentSpeed;
        }
        #endregion


    }
}

