using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    public class ToSceneButton : ButtonComponentBase
    {
        #region Scene Data
        [Header("Scene Data")]

        [Tooltip("The scene name")]
        [SerializeField]
        private string _sceneName;
        #endregion

        #region Overridable
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            UnityEngine.SceneManagement.SceneManager.LoadScene(_sceneName);
        }
        #endregion
    }

}
