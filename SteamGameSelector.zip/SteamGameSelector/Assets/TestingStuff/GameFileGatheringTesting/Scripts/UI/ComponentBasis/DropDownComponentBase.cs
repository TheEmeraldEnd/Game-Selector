using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using System.Linq;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to make drop down components more easily useful
    /// </summary>
    [RequireComponent(typeof(TMP_Dropdown))]
    public class DropDownComponentBase : MonoBehaviour
    {
        #region Component Related
        [Header("Component Related")]

        [Tooltip("The drop down component")]
        [SerializeField, HideInInspector]
        private TMP_Dropdown _dropdownComponent;

        private void InitializeComponent()
        {
            if (_dropdownComponent == null)
                _dropdownComponent = this.GetComponent<TMP_Dropdown>();
        }
        #endregion

        #region Invokeable Overridable Events
        protected virtual void OverridableOnValueChanged()
        {

        }
        #endregion

        #region Unity Methods
        private void OnEnable()
        {
            InitializeComponent();

            _dropdownComponent.onValueChanged.AddListener(delegate { OverridableOnValueChanged(); });

            OverridableOnEnable();
        }

        private void OnDisable()
        {
            OverridableOnDisable();

            _dropdownComponent.onValueChanged.RemoveAllListeners();
        }
        #endregion

        //!Protected Methods
        #region Getters
        /// <summary>
        /// Gets the selected option
        /// </summary>
        protected TMP_Dropdown.OptionData SelectedOption
        {
            get
            {
                return _dropdownComponent.options[OptionsIndexValue];
            }
        }

        /// <summary>
        /// Gets the current value of the dropdown
        /// </summary>
        protected int OptionsIndexValue
        {
            get
            {
                return _dropdownComponent.value;
            }
        }

        /// <summary>
        /// Gets the list of option texts
        /// </summary>
        protected string[] GetOptionTexts()
        {
            return _dropdownComponent.options.Select(o => o.text).ToArray();
        }

        /// <summary>
        /// Get the text of the text
        /// </summary>
        /// <returns></returns>
        protected string GetCurrentOptionText()
        {
            return SelectedOption.text;
        }
        #endregion

        #region Setters
        /// <summary>
        /// Sets the option texts into the dropdown options
        /// </summary>
        /// <param name="optionTextsOrNames"></param>
        protected void SetOptionTexts(string[] optionTextsOrNames)
        {
            List<TMP_Dropdown.OptionData> optionData = new();
            foreach (string optionText in optionTextsOrNames)
            {
                TMP_Dropdown.OptionData option = new();
                option.text = optionText;
                optionData.Add(option);
            }
            optionData.TrimExcess();
            _dropdownComponent.options = optionData;
        }

        /// <summary>
        /// CLears the options
        /// </summary>
        protected void ClearOptions()
        {
            _dropdownComponent.ClearOptions();
        }
        #endregion

        #region Overridable Methods
        protected virtual void OverridableOnEnable()
        {

        }

        protected virtual void OverridableOnDisable()
        {

        }
        #endregion
    }

}
