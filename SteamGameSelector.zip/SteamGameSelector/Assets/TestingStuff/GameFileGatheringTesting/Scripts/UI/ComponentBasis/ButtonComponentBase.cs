using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used as the basis for buttons
    /// </summary>
    [RequireComponent(typeof(Button))]
    public class ButtonComponentBase : MonoBehaviour
    {
        #region Component Related
        [Header("Component Related")]

        [Tooltip("Used to control what is being pressed")]
        [SerializeField, HideInInspector]
        private Button buttonComponent;

        private void InitializeComponents()
        {
            if (buttonComponent == null)
                buttonComponent = GetComponent<Button>();
        }
        #endregion

        #region Invokable event
        protected virtual void InvokableOnClick()
        {

        }
        #endregion

        #region Unity Methods
        private void Awake()
        {
            InitializeComponents();
        }

        private void OnEnable()
        {
            buttonComponent.onClick.AddListener(delegate { InvokableOnClick(); });
        }

        private void OnDisable()
        {
            buttonComponent.onClick.RemoveAllListeners();
        }
        #endregion
    }
}

