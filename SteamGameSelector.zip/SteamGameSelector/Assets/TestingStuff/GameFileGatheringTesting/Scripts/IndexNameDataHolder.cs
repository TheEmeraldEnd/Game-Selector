using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to hold the names of the file locations of the text files used to get the games
    /// </summary>
    public class IndexNameDataHolder : MonoBehaviour
    {
        [Header("Index Names")]

        [Tooltip("The text file used to identify where game libraries are")]
        [SerializeField]
        private string _gameLibrariesTextFilePath;
        public string GameLibraroesTextFilePath
        {
            get { return _gameLibrariesTextFilePath; }
        }

        [Tooltip("The text file path used to identify where the games executable is located " +
            "(just the name of the file) [Place where you need a game played]")]
        [SerializeField]
        private string _gameExecutableFileName;
        public string GameExecutableFileName
        {
            get { return _gameExecutableFileName; }
        }

        [Tooltip("The text file used to identify what files to ignore")]
        [SerializeField]
        private string _ignoreFileName;
        public string IgnoreFileName
        {
            get { return _ignoreFileName; }
        }
    }
}

