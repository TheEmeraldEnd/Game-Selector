using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to set the game executables
    /// </summary>
    public class GameExecutablesHolder : MonoBehaviour
    {
        #region Data
        [Header("Data related")]

        [Tooltip("The list that holds the list of game executables path")]
        [SerializeField]
        private List<GameData> _executablePaths;

        public GameData[] AllGameData
        {
            get
            {
                return _executablePaths.ToArray();
            }
        }
        #endregion

        private void Start()
        {
            _executablePaths = FileAccessor.GetAllGameData().ToList();
        }
    }

}
