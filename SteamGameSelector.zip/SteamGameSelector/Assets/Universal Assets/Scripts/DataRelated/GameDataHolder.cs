using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GameSelectorScripts;
using GlobalScripts;
using System.Linq;
using System.IO;
using TMPro;

namespace GlobalScripts
{
    /// <summary>
    /// Used to hold the data of games that are located in and gets the games from file
    /// </summary>
    [System.Serializable]
    public class GameDataHolder : MonoBehaviour
    {
        #region Game Data
        [Header("Game Data")]

        [Tooltip("Used to hold the game data")]
        [SerializeField]
        private GameData[] _gameData;

        public GameData[] GetGameData()
        {
            return _gameData;
        }
        #endregion

        #region Unity Methods
        private void Awake()
        {
            //Set up the text file
            string exeFilePath = UnityFileAccessorStatic.CompleteGameExecutablesTextPath;
            UnityFileAccessorStatic.SetUpTextFile(exeFilePath);

            //Set data from game data (assumes data is in Json)
            string[] gameDataAsJson = UnityFileAccessorStatic.GetLinesFromTextFile(exeFilePath);
            List<GameData> gameDataList = new();

            if (gameDataAsJson.Length == 0)
            {
            }
            else if (gameDataAsJson.Length > 0)
            {
                foreach (string line in gameDataAsJson)
                {
                    GameData newGameObject = new();
                    newGameObject = JsonUtility.FromJson<GameData>(line);
                    gameDataList.Add(newGameObject);
                }
                gameDataList.TrimExcess();
            }
            

            //Set the temp list into the saved game data
            if (gameDataList.Count > 0)
                _gameData = gameDataList.OrderBy(g => g.GameName).ToArray();
            else
                _gameData = new GameData[0];

            //!Used to write games for testing purposes
            //string[] JsonRepresentation = new string[_gameData.Length];
            //for(int i = 0; i < _gameData.Length; i++)
            //{
            //    JsonRepresentation[i] = _gameData[i].ToString();
            //}
            //UnityFileAccessorStatic.WriteLinesToTextFile(
            //    UnityFileAccessorStatic.CompleteGameExecutablesTextPath,
            //    JsonRepresentation);
        }
        #endregion

        /// <summary>
        /// Adds the game data to a list
        /// </summary>
        /// <param name="incomingGameData"></param>
        public void AddGameDataToList(GameData incomingGameData)
        {
            List<GameData> tempGameList = _gameData.ToList();
            tempGameList.Add(incomingGameData);
            tempGameList.TrimExcess();
            _gameData = tempGameList.ToArray();
        }

        /// <summary>
        /// Deletes a game data
        /// </summary>
        /// <param name="incomingGameData"></param>
        public void DeleteGameData(GameData incomingGameData)
        {
            List<GameData> tempGameList = _gameData.ToList();
            
            for(int i = 0; i < tempGameList.Count; i++)
            {
                if (_gameData[i].GameName == incomingGameData.GameName)
                {
                    tempGameList.RemoveAt(i);
                    tempGameList.TrimExcess();
                    _gameData = tempGameList.ToArray();
                    return;
                }
            }
        }
    }
}

