using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GlobalScripts
{
    /// <summary>
    /// Used to get the data of the game holder
    /// </summary>
    public static class GameDataAccessorStatic
    {
        /// <summary>
        /// Used to get the game datqa
        /// </summary>
        private static GameDataHolder _gameDataHolderRef = null;
        private static GameDataHolder GameDataHolderRef
        {
            get
            {
                if (_gameDataHolderRef == null)
                    _gameDataHolderRef = GameObject.FindObjectOfType<GameDataHolder>();

                return _gameDataHolderRef;
            }
        }

        /// <summary>
        /// Get's the data of the games
        /// </summary>
        public static GameData[] GameData
        {
            get
            {
                return GameDataHolderRef.GetGameData();
            }
        }

        /// <summary>
        /// Get's the name of the games
        /// </summary>
        /// <returns></returns>
        public static string[] GetGameNames()
        {
            return GameData.Select(g => g.GameName).ToArray();
        }

        /// <summary>
        /// Get's the executable paths of the games
        /// </summary>
        /// <returns></returns>
        public static string[] GetExecutablePaths()
        {
            return GameData.Select(g => g.ExecutablePath).ToArray();
        }

        /// <summary>
        /// A public way to add game daat to list
        /// </summary>
        /// <param name="incomingGameData"></param>
        public static void AddGameDataToList(GameData incomingGameData)
        {
            foreach (var gameData in GameData)
            {
                if (gameData.GameName.ToUpper() == incomingGameData.GameName.ToUpper())
                {
                    return;
                }
            }

            GameDataHolderRef.AddGameDataToList(incomingGameData);
        }

        /// <summary>
        /// A public list that saves the list to the executable storage
        /// </summary>
        public static void SaveListToExecutable()
        {
            //Get's the storage path and sets up failsafe
            string storagePath = UnityFileAccessorStatic.CompleteGameExecutablesTextPath;
            UnityFileAccessorStatic.SetUpTextFile(storagePath);

            //Gets and save the json data
            string[] jsonGameData = GameData.Select(g => g.ToString()).ToArray();
            UnityFileAccessorStatic.WriteLinesToTextFile(storagePath, jsonGameData);
        }

        /// <summary>
        /// Deletes a selected game that is stated by incom,ingGameData
        /// </summary>
        /// <param name="incomingGameData"></param>
        public static void DeleteGame(GameData incomingGameData)
        {
            GameDataHolderRef.DeleteGameData(incomingGameData);
        }
    }
}