using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GameSelectorScripts
{
    /// <summary>
    /// Used to select what game is being played
    /// </summary>
    public class GameSelectorDropDown : DropDownComponentBase
    {
        #region Unity Methods
        private void Start()
        {
            ClearOptions();

            string[] gameOptionNames = GameDataAccessorStatic.GetGameNames();
            SetOptionTexts(gameOptionNames);
        }
        #endregion

        #region Accessors
        public string GetSelectedGameName()
        {
            return GetOptionTexts()[OptionsIndexValue];
        }
        #endregion
    }
}