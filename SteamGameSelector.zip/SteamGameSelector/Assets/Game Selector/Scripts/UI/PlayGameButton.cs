using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GlobalScripts;
using System.Diagnostics;

namespace GameSelectorScripts
{
    /// <summary>
    /// Used to play the current game that is being selected
    /// </summary>
    public class PlayGameButton : ButtonComponentBase
    {
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            PlaySelectedApplication();
        }

        private void PlaySelectedApplication()
        {
            string executablePath = GameSelectorDataStatic.GetSelectedGameData().ExecutablePath;

            var process = new Process();
            process.StartInfo.FileName = executablePath;
            process.Start();

            Application.Quit();
        }
    }
}

