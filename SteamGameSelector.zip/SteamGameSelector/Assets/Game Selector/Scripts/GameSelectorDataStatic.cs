using GlobalScripts;
using UnityEngine;

namespace GameSelectorScripts
{
    /// <summary>
    /// Gets anything related to the UI data of the game selector scene
    /// </summary>
    public static class GameSelectorDataStatic
    {
        #region Game Selector Drop Down
        /// <summary>
        /// Get's the reference to the game selector drop down
        /// </summary>
        private static GameSelectorDropDown _gameSelectorDropDownRef = null;
        private static GameSelectorDropDown GameSelectorDropDownRef
        {
            get
            {
                if (_gameSelectorDropDownRef == null)
                    _gameSelectorDropDownRef = GameObject.FindObjectOfType<GameSelectorDropDown>();

                return _gameSelectorDropDownRef;
            }
        }

        /// <summary>
        /// Get's the game data of the selected game
        /// </summary>
        /// <returns></returns>
        public static GameData GetSelectedGameData()
        {
            foreach(var gameData in GameDataAccessorStatic.GameData)
                if (gameData.GameName == GameSelectorDropDownRef.GetSelectedGameName())
                    return gameData;

            return new();
        }
        #endregion
    }
}