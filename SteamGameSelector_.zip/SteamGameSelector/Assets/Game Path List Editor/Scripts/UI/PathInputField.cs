using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to set the path of the new 
    /// </summary>
    public class PathInputField : InputComponentBase
    {

    }
}
