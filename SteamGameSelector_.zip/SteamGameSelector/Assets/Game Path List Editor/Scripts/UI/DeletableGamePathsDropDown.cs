using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to show the selected game that is being looked at to be deleted
    /// </summary>
    public class DeletableGamePathsDropDown : DropDownComponentBase
    {
        public string SelectedGameName
        {
            get
            {
                return GetCurrentOptionText();
            }
        }
    }
}