using GlobalScripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamePathListEditor
{
    /// <summary>
    /// Used to contain the namespace field
    /// </summary>
    public class NameInputField : InputComponentBase
    {
    }
}

