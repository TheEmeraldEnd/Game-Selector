using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerControllerScene
{
    /// <summary>
    /// Used to quic the application
    /// </summary>
    public class QuitApplicationInteractable : MonoBehaviour, IInteractable
    {
        public void IOnInteract()
        {
            Application.Quit();
        }
    }

}
