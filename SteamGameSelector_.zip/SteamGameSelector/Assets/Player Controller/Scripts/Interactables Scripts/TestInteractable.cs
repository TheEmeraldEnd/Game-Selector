using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PlayerControllerScene;

namespace PlayerControllerScene
{
    public class TestInteractable : MonoBehaviour, IInteractable
    {
        public void IOnInteract()
        {
            print("Interactable Works");
        }
    }
}

