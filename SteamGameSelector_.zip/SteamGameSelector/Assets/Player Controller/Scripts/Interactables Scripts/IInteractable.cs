using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerControllerScene
{
    /// <summary>
    /// An interface used to determine what is interactable
    /// </summary>
    public interface IInteractable
    {
        public void IOnInteract();
    }
}