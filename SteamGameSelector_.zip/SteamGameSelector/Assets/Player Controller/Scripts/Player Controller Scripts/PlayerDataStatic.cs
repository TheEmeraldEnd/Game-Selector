using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerControllerScene
{
    /// <summary>
    /// A public class that allows the player components to talk to eachother via methods
    /// </summary>
    public static class PlayerDataStatic
    {
        #region Player Game Data
        private static string _playerTag = "Player";

        private static GameObject _playerGameObjectRef;
        private static GameObject PlayerGameObjectRef
        {
            get
            {
                if (_playerGameObjectRef == null)
                    _playerGameObjectRef = GameObject.FindGameObjectWithTag(_playerTag);

                return _playerGameObjectRef;
            }
        }
        #endregion

        #region Rigidbody Data
        private static Rigidbody2D _rigidBody2DRef;
        private static Rigidbody2D RigidBody2DRef
        {
            get
            {
                if (_rigidBody2DRef == null)
                    _rigidBody2DRef = PlayerGameObjectRef.GetComponent<Rigidbody2D>();

                return _rigidBody2DRef;
            }
        }

        /// <summary>
        /// Sets the velocity of the player
        /// </summary>
        /// <param name="velocity"></param>
        public static void SetPlayerVelocity(Vector2 velocity)
        {
            RigidBody2DRef.velocity = velocity;
        }

        /// <summary>
        /// Get's the velocity of the player
        /// </summary>
        public static Vector2 GetPlayerVelocity()
        {
            return RigidBody2DRef.velocity;
        }
        #endregion

        #region Collider Data
        private static Collider2D _collider2DRef;
        private static Collider2D Collider2DRef
        {
            get
            {
                if (_collider2DRef == null)
                    _collider2DRef = PlayerGameObjectRef.GetComponent<Collider2D>();

                return _collider2DRef;
            }
        }
        #endregion

        #region Animator Data
        private static Animator _playerAnimatorRef;
        private static Animator PlayerAnimatorRef
        {
            get
            {
                if (_playerAnimatorRef == null)
                    _playerAnimatorRef = PlayerGameObjectRef.GetComponent<Animator>();

                return _playerAnimatorRef;
            }
        }

        /// <summary>
        /// Set's the animation of the player being animated
        /// </summary>
        /// <param name="animationName"></param>
        public static void SetAnimation(string animationName)
        {
            PlayerAnimatorRef.Play(animationName);
        }
        #endregion
    }
}

