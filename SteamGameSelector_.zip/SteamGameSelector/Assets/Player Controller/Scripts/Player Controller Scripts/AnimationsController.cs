using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerControllerScene
{
    /// <summary>
    /// Controls what animation that is being played in the player animator
    /// </summary>
    public class AnimationsController : MonoBehaviour
    {
        #region Animation Motion Names
        [Header("Motion Animation Names")]

        [Tooltip("Idle Name")]
        [SerializeField]
        private string _idleAnimationName = "Idle";

        [Tooltip("Walking Name")]
        [SerializeField]
        private string _walkingAnimationName = "Walking";
        #endregion

        #region Animation Direction Names
        [Header("Animation Direction Names")]

        [Tooltip("North Name")]
        [SerializeField]
        private string _northAnimationName = "North";

        [Tooltip("South Name")]
        [SerializeField]
        private string _southAnimationName = "South";

        [Tooltip("East Name")]
        [SerializeField]
        private string _eastAnimationName = "East";

        [Tooltip("West Name")]
        [SerializeField]
        private string _westAnimationName = "West";
        #endregion

        #region Animation States
        [Header("Last Animation State")]

        [Tooltip("Used to store the last known direction")]
        [SerializeField, HideInInspector]
        private string _lastFrameDirectionAnimation = "South";

        [Tooltip("Used to store if the last animation was moveing or not")]
        [SerializeField, HideInInspector]
        private string _lastFrameSpeedAnimation = "Idle";

        /// <summary>
        /// Determines the direction if used
        /// </summary>
        /// <returns></returns>
        private string DetermineDirection()
        {
            //Get the variables needed to calculate the animation
            Vector2 velocity = PlayerDataStatic.GetPlayerVelocity();

            //return last known direction if there isn't a direction to go to
            if (velocity.magnitude == 0)
                return _lastFrameDirectionAnimation;

            string tempDirection = "";
            //Get the horizontal direction
            float horizontalValue = velocity.x;
            if (horizontalValue < 0f)
                tempDirection = _westAnimationName;
            else if (horizontalValue > 0f)
                tempDirection = _eastAnimationName;

            //Get the vertical direction
            float verticalValue = velocity.y;
            if (verticalValue < 0f)
                tempDirection = _southAnimationName;
            else if (verticalValue > 0f)
                tempDirection = _northAnimationName;

            return tempDirection;
        }

        /// <summary>
        /// Determines the motion of the animation being played
        /// </summary>
        /// <returns></returns>
        private string DetermineSpeedAnimation()
        {
            float magnitude = PlayerDataStatic.GetPlayerVelocity().magnitude;

            if (magnitude == 0f)
                return _idleAnimationName;
            else
                return _walkingAnimationName;
        }
        #endregion

        #region Unity Methods
        private void Update()
        {
            //Set up the animation string
            string currentDirection = DetermineDirection();
            string currentSpeed = DetermineSpeedAnimation();
            string animationString = currentSpeed + currentDirection;

            if (animationString != (_lastFrameSpeedAnimation + _lastFrameDirectionAnimation))
                PlayerDataStatic.SetAnimation(animationString);

            _lastFrameDirectionAnimation = currentDirection;
            _lastFrameSpeedAnimation = currentSpeed;
        }
        #endregion
    }
}

