using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to get all the game data elements
    /// </summary>
    public static class GameDataAccessor
    {
        #region Game Data Holder
        private static GameExecutablesHolder _gameDataHolderRef;
        private static GameExecutablesHolder GameDataHolderRef
        {
            get
            {
                if (_gameDataHolderRef == null)
                {
                    _gameDataHolderRef = GameObject.FindObjectOfType<GameExecutablesHolder>();
                }

                return _gameDataHolderRef;
            }
        }

        /// <summary>
        /// Get all the base data
        /// </summary>
        public static GameData[] AllGameData
        {
            get { return GameDataHolderRef.AllGameData; }
        }

        /// <summary>
        /// Get all the game names
        /// </summary>
        public static string[] AllGameNames
        {
            get
            {
                return AllGameData.Select(g => g.GameName).ToArray();
            }
        }

        /// <summary>
        /// Get all the executable paths
        /// </summary>
        public static string[] AllGameExecutables
        {
            get { return AllGameData.Select(g => g.ExecutablePath).ToArray(); }
        }

        /// <summary>
        /// Get all the full game paths
        /// </summary>
        public static string[] AllGamePaths
        {
            get { return AllGameData.Select(g => g.GamePath).ToArray(); }
        }
        #endregion

        #region Selected Game Data
        private static GameNameDropDown _gameDropDownRef;
        private static GameNameDropDown GameDropDownRef
        {
            get
            {
                if (_gameDropDownRef == null)
                {
                    _gameDropDownRef = GameObject.FindObjectOfType<GameNameDropDown>();
                }

                return _gameDropDownRef;
            }
        }

        public static GameData SelectedGameData()
        {
            return AllGameData.First(s => s.GameName == GameDropDownRef.SelectedGameName);
        }
        #endregion
    }

}
