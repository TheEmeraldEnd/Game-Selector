using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

namespace V0_1
{
    /// <summary>
    /// Used to play the game
    /// </summary>
    public class PlayGameButton : ButtonComponentBase
    {
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            PlaySelectedApplication();
        }

        private void PlaySelectedApplication()
        {
            string executablePath = GameDataAccessor.SelectedGameData().ExecutablePath;

            var process = new Process();
            process.StartInfo.FileName = executablePath;
            process.Start();

            Application.Quit();
        }
    }
}

