using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to select the game option
    /// </summary>
    public class GameNameDropDown : DropDownComponentBase
    {
        protected override void OverridableOnEnable()
        {
            base.OverridableOnEnable();

            ClearOptions();

            StartCoroutine(AddArtificialDelay(0.01f));
        }

        protected IEnumerator AddArtificialDelay(float delay)
        {
            yield return new WaitForSeconds(delay);
            SetOptionTexts(GameDataAccessor.AllGameNames);
        }

        public string SelectedGameName
        {
            get
            {
                return SelectedOption.text;
            }
        }

    }
}

