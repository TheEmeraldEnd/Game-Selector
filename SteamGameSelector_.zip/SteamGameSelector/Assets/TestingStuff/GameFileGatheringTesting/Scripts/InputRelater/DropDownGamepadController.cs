using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace V0_1
{
    /// <summary>
    /// Helps with navigation in the scroolbar making the dropdown accessable with controllers
    /// </summary>
    public class DropDownGamepadController : DropDownComponentBase
    {
        #region Component
        [Header("Component Related")]

        [Tooltip("Used to get the scrolling component")]
        [SerializeField]
        private ScrollRect _scrollRectComponent;
        #endregion

        #region Set first selectable if inputs switch
        /// <summary>
        /// Get's all selectable's in children
        /// </summary>
        /// <returns></returns>
        private Selectable[] GetAllSelectablesChildren()
        {
            var childrenSelectables = GetComponentsInChildren<Selectable>();

            return childrenSelectables;
        }

        /// <summary>
        /// Set selected to first selectable
        /// </summary>
        private void SetSelectedToFirstSelectable(GameObject firstSelectable)
        {
            EventSystem.current.SetSelectedGameObject(firstSelectable);
        }

        /// <summary>
        /// Set the first selectable
        /// </summary>
        private void SetFirstSelectableOnControlSwitch()
        {
            //Get first selectable
            GameObject firstSelectable = GetAllSelectablesChildren()[1].gameObject;

            //Set to the first selected if dropdown  
            if (EventSystem.current.currentSelectedGameObject.name == "Blocker")
                SetSelectedToFirstSelectable(firstSelectable);
        }
        #endregion

        #region Set scroll
        /// <summary>
        /// Get the index of the selectable being looked at
        /// </summary>
        /// <returns></returns>
        private int GetSelectableIndex(string[] optionNames)
        {
            string currentSelection = EventSystem.current.currentSelectedGameObject.name;
            int index = -1;

            for (int i = 0; i < optionNames.Length; i++)
                if (optionNames[i] == currentSelection)
                    index = i;

            return index;
        }

        /// <summary>
        /// Get the names of the selectables
        /// </summary>
        /// <returns></returns>
        private string[] GetSelectablesNames()
        {
            List<string> names = new();
            names = GetAllSelectablesChildren().Select(g => g.gameObject.name).ToList();
            names.RemoveAt(0);
            names.RemoveAt(names.Count - 1);
            return names.ToArray();
        }

        /// <summary>
        /// Get's a value for the current option being looked at
        /// </summary>
        /// <param name="optionIndex"></param>
        /// <param name="maxOptions"></param>
        /// <returns></returns>
        private float GetSelectableIndexByPercentage(int optionIndex, int maxOptions)
        {
            //Set a check if the max is 0 (just in case)
            if (maxOptions == 0)
                return 0f;

            //Set a check if index is -1 (not selecting a selectable)
            if (optionIndex == -1)
                return 0f;

            // return a percentage (The - 1 is to account for 0 being the first index)
            return (float)optionIndex / (float)(maxOptions - 1);
        }
        #endregion

        #region Unity Methods
        private void Update()
        {
            //Get the component
            _scrollRectComponent = this.gameObject.GetComponentInChildren<ScrollRect>();

            if (_scrollRectComponent != null && GlobalStaticInput.IsControllerControllerConnected())
            {
                //Apply the value of the dropdown of what is being looked at to the scroll rect
                string[] optionNames = GetSelectablesNames();
                int optionIndex = GetSelectableIndex(optionNames);
                float indexAsPercentage = GetSelectableIndexByPercentage(optionIndex, optionNames.Length);
                _scrollRectComponent.verticalNormalizedPosition = (1 - indexAsPercentage);

                //Set the first selectable on input switch
                SetFirstSelectableOnControlSwitch();
            }
        }
        #endregion
    }
}

