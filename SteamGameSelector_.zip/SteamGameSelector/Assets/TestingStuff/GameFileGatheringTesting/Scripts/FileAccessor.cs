using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Linq;
using Unity.VisualScripting.FullSerializer;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to access any files related to the games
    /// </summary>
    public static class FileAccessor
    {
        #region Index Names
        private static IndexNameDataHolder _indexNameDataHolderRef;
        private static IndexNameDataHolder IndexNameDataHolderRef
        {
            get
            {
                if (_indexNameDataHolderRef == null)
                    _indexNameDataHolderRef = Object.FindObjectOfType<IndexNameDataHolder>();

                return _indexNameDataHolderRef;
            }
        }

        private static string GameLibraryExecutablesPathIndex
        {
            get
            {
                return IndexNameDataHolderRef.GameLibraroesTextFilePath;
            }
        }

        private static string GameExecutableFileNameIndex
        {
            get
            {
                return IndexNameDataHolderRef.GameExecutableFileName;
            }
        }

        private static string IgnoreTextFileNameIndex
        {
            get
            {
                return IndexNameDataHolderRef.IgnoreFileName;
            }
        }
        #endregion

        #region Game Files Access
        /// <summary>
        /// Get the game libraries from the disk
        /// </summary>
        /// <returns></returns>
        private static string[] GetGameLibraryPaths()
        {
            //Find the text file containing the game libraries
            string textfile = "C:\\" + GameLibraryExecutablesPathIndex;

            //Return the paths that exist
            List<string> viablePaths = new();
            foreach (var line in File.ReadAllLines(textfile))
            {
                if (Directory.Exists(line) || File.Exists(line))
                    viablePaths.Add(line);
            }
            viablePaths.TrimExcess();

            return viablePaths.ToArray();

        }

        /// <summary>
        /// Returns all the game data to whatever is calling for it
        /// </summary>
        /// <returns></returns>
        public static GameData[] GetAllGameData()
        {
            List<GameData> allGameData = new();
            foreach (var library in GetGameLibraryPaths())
            {
                allGameData.AddRange(GetGameData(library));
            }
            allGameData.TrimExcess();

            return allGameData.ToArray();
        }

        /// <summary>
        /// Returns all the game data if there is everything is set
        /// </summary>
        /// <param name="gameLibraryPath"></param>
        /// <returns></returns>
        public static GameData[] GetGameData(string gameLibraryPath)
        {
            //Get the library info
            DirectoryInfo gameLibraryDirectoryInfo = new(gameLibraryPath);
            string[] filesToIgnore = GetIgnoredFiles(gameLibraryPath);

            //Get the info of all the playable games
            List<GameData> allGameData = new();
            foreach (var subdirectories in gameLibraryDirectoryInfo.GetDirectories())
            {
                if (filesToIgnore.Contains(subdirectories.FullName))
                {

                }
                else
                {
                    //Get the game info for each game
                    GameData currentGameData = new();

                    currentGameData.GameName = subdirectories.Name;
                    currentGameData.GamePath = subdirectories.FullName;
                    currentGameData.ExecutablePath = GetExecutablePath(subdirectories.FullName);
                    allGameData.Add(currentGameData);
                }
            }
            allGameData.TrimExcess();

            return allGameData.ToArray();
        }

        /// <summary>
        /// Get's the executable path to play the game listed
        /// </summary>
        /// <returns></returns>
        private static string GetExecutablePath(string gamePathWithName)
        {
            string executableLocator = $"{gamePathWithName}\\{GameExecutableFileNameIndex}";

            //Return the (should be) one and only line
            return File.ReadAllLines(executableLocator)[0];
        }

        /// <summary>
        /// Get file paths that are to be ignored
        /// </summary>
        /// <param name="gameLibraryPath"></param>
        /// <returns></returns>
        public static string[] GetIgnoredFiles(string gameLibraryPath)
        {
            string ignoreFileTextPath = $"{gameLibraryPath}\\{IgnoreTextFileNameIndex}";

            //Get the vaiable directories that are able to be ignored (check if they exist)_
            List<string> ignoredFilePaths = new();

            if (!File.Exists(ignoreFileTextPath))
            {
                return new string[0];
            }

            foreach (var line in File.ReadAllLines(ignoreFileTextPath))
            {
                if (Directory.Exists(line) || File.Exists(line))
                {
                    ignoredFilePaths.Add(line);
                }
            }
            ignoredFilePaths.TrimExcess();

            return ignoredFilePaths.ToArray();
        }
        #endregion
    }

}
