using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to identify a game and it's elements
    /// </summary>
    [System.Serializable]
    public class GameData
    {
        [Tooltip("The name of the game")]
        [SerializeField]
        private string gameName;
        public string GameName
        {
            get { return gameName; }
            set { gameName = value; }
        }

        [Tooltip("The path of the executable")]
        [SerializeField]
        private string executablePath;
        public string ExecutablePath
        {
            get { return executablePath; }
            set { executablePath = value; }
        }

        [Tooltip("The path of the game")]
        [SerializeField]
        private string gamePath;
        public string GamePath
        {
            get { return gamePath; }
            set { gamePath = value; }
        }
    }

}
