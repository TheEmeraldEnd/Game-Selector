using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    public class InteractableToScene : TriggerBaseScript, IInteractable
    {
        #region Scene Data
        [Tooltip("The name of the scene to change to")]
        [SerializeField]
        private string _toSceneName;
        #endregion

        public void OnInteract()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(_toSceneName);
        }
    }

}
