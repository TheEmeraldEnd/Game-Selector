using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used if required to have a trigger
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class TriggerBaseScript : MonoBehaviour
    {
        #region Component
        [Header("Component Monobehavior")]

        [Tooltip("Used as the collider to check if something is inside")]
        [SerializeField, HideInInspector]
        private Collider2D collider;

        private void InitializeComponent()
        {
            if (collider == null)
            {
                collider = GetComponent<Collider2D>();
            }
        }
        #endregion

        #region Unity Methods
        private void OnEnable()
        {
            InitializeComponent();
        }
        #endregion
    }

}
