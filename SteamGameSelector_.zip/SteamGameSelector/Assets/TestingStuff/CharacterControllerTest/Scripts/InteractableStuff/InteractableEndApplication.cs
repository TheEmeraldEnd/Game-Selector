using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Ends application on interaction
    /// </summary>
    public class InteractableEndApplication : TriggerBaseScript, IInteractable
    {
        public void OnInteract()
        {
            Application.Quit();
        }
    }

}
