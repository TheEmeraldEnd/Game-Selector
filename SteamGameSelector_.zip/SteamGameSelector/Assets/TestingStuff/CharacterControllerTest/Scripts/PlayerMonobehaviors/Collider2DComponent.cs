using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used as the base class for collider components
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class Collider2DComponent : MonoBehaviour
    {
        #region Component
        [Header("Component Related")]

        [Tooltip("The collider component of whatever this is attached to")]
        [SerializeField, HideInInspector]
        private Collider2D _colliderComponent;

        private void InitializeComponents()
        {
            if (_colliderComponent == null)
                _colliderComponent = GetComponent<Collider2D>();
        }
        #endregion

        #region Unity Methods
        private void OnEnable()
        {
            InitializeComponents();
        }
        #endregion
    }
}

