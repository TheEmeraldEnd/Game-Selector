using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to interact with the enviroment whenever the interact button is pressed
    /// </summary>
    public class InteractController : Collider2DComponent
    {
        #region The interactable Button
        [Header("Interactable")]

        [Tooltip("The interactable thing")]
        [SerializeField]
        private IInteractable _interactable;
        #endregion

        #region Input Action
        public void Interact(InputAction.CallbackContext cxt)
        {
            if (_interactable != null)
                _interactable.OnInteract();
        }
        #endregion

        #region Get Interactable Stuff
        private void OnCollisionEnter2D(Collision2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = interactable;
        }

        private void OnCollisionExit2D(Collision2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = null;
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = interactable;
        }

        private void OnTriggerExit2D(Collider2D collision)
        {
            IInteractable interactable = collision.gameObject.GetComponent<IInteractable>();

            if (interactable != null)
                _interactable = interactable;
        }
        #endregion
    }
}

