using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using V0_1;

namespace V0_1
{
    /// <summary>
    /// Used to gather and set the rigidbody component from the gameobject 
    ///     this is applied to.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D))]
    public class Rigidbody2DComponent : MonoBehaviour
    {
        #region Component related
        [Header("Component Related")]

        [Tooltip("The rigidbody used to control the game object")]
        [SerializeField, HideInInspector]
        private Rigidbody2D _rigidbody;

        private void InitializeComponents()
        {
            if (_rigidbody == null)
            {
                _rigidbody = GetComponent<Rigidbody2D>();
            }
        }
        #endregion

        #region Overridable Events
        /// <summary>
        /// Used to override a specific that is called in unity from "OnEnable."
        /// Initializing components still happens anywhay
        /// </summary>
        protected virtual void OverridableOnEnable()
        {

        }

        /// <summary>
        /// Used to override a specific that is called in unity from "OnEnable."
        /// Initializing components still happens anywhay
        /// </summary>
        protected virtual void OverridableOnDisable()
        {

        }
        #endregion

        #region Unity Methods
        private void OnEnable()
        {
            InitializeComponents();

            OverridableOnEnable();
        }

        private void OnDisable()
        {
            OverridableOnDisable();
        }
        #endregion

        #region Rigidbody Methods
        /// <summary>
        /// Tell which direction the rigidbody should go and at what speed
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="speed"></param>
        protected void SetRigidbodyVelocity(Vector2 direction, float speed)
        {
            //Safegaurd against no direction
            if (direction.magnitude == 0)
                _rigidbody.velocity = direction;
            else
                _rigidbody.velocity = direction.normalized * speed;
        }

        /// <summary>
        /// Get the velocity of the rigidbody
        /// </summary>
        /// <returns></returns>
        protected Vector2 GetRigidbodyVelocity()
        {
            return _rigidbody.velocity;
        }
        #endregion
    }
}

