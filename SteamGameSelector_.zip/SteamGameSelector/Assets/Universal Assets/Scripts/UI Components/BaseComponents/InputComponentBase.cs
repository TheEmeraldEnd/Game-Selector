using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace GlobalScripts
{
    /// <summary>
    /// Used to get and operate the input components as a base
    /// </summary>
    public class InputComponentBase : MonoBehaviour
    {
        #region Component
        [Header("Component Data")]

        [Tooltip("The input that is being edited")]
        [SerializeField, HideInInspector]
        private TMP_InputField _inputFieldComponent;

        private void InitializeComponent()
        {
            if (_inputFieldComponent == null)
                _inputFieldComponent = this.GetComponent<TMP_InputField>();
        }
        #endregion

        #region Unity Methods
        private void Awake()
        {
            InitializeComponent();
        }

        private void OnEnable()
        {
            _inputFieldComponent
                .onValueChanged
                .AddListener(delegate { InvokableOnValueChanged(_inputFieldComponent.text); });

            _inputFieldComponent
                .onEndEdit
                .AddListener(delegate { InvolabkeOnEndEdit(_inputFieldComponent.text); });

            _inputFieldComponent
                .onSelect
                .AddListener(delegate { InvokableOnSelect(_inputFieldComponent.text); });

            _inputFieldComponent
                .onDeselect
                .AddListener(delegate { InvokableOnDeselect(_inputFieldComponent.text); });

            OverridableOnEnable();
        }

        private void OnDisable()
        {
            OverridableOnDisable();

            _inputFieldComponent.onValueChanged.RemoveAllListeners();

            _inputFieldComponent.onEndEdit.RemoveAllListeners();

            _inputFieldComponent.onSelect.RemoveAllListeners();

            _inputFieldComponent.onDeselect.RemoveAllListeners();
        }
        #endregion

        #region Overridable Unity Methods
        protected void OverridableOnEnable()
        {

        }

        protected void OverridableOnDisable()
        {

        }
        #endregion

        #region Protected Accessors
        protected virtual void InvokableOnValueChanged(string incomingString)
        {
            
        }

        protected virtual void InvolabkeOnEndEdit(string incomingString)
        {

        }

        protected virtual void InvokableOnSelect(string incomingString)
        {

        }

        protected virtual void InvokableOnDeselect(string incomingString)
        {

        }
        #endregion

        #region Public accessor Methods
        /// <summary>
        /// The input field text being able to send and recieve the text by code for the text
        /// </summary>
        public string InputText
        {
            get { return _inputFieldComponent.text; }
            set { _inputFieldComponent.text = value;}
        }

        public void ClearInput()
        {
            InputText = "";
        }
        #endregion
    }
}

