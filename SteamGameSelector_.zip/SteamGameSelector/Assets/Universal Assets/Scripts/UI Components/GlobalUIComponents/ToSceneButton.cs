using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GlobalScripts
{
    /// <summary>
    /// Used to get to a scene based on drag and drop methods
    /// </summary>
    public class ToSceneButton : ButtonComponentBase
    {
        #region Scene Data
        [Header("Scene Data")]

        [Tooltip("The scene that will go to")]
        [SerializeField]
        private string _toSceneName;
        #endregion

        #region Click Methods
        protected override void InvokableOnClick()
        {
            base.InvokableOnClick();

            SceneManager.LoadScene(_toSceneName);
        }
        #endregion
    }
}