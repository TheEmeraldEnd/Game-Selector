using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GlobalScripts
{
    /// <summary>
    /// used to contain details of a game
    /// </summary>
    [System.Serializable]
    public class GameData
    {
        [Tooltip("The name of the game")]
        [SerializeField]
        private string gameName;
        public string GameName
        {
            get { return gameName; }
            set { gameName = value; }
        }

        [Tooltip("The path of the executable")]
        [SerializeField]
        private string executablePath;
        public string ExecutablePath
        {
            get { return executablePath; }
            set { executablePath = value; }
        }

        /// <summary>
        /// Returns the game data as a json string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return JsonUtility.ToJson(this, false);
        }
    }
}