using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace GlobalScripts
{
    public static class GlobalStaticInput
    {
        #region Input Seeker
        private static PlayerInput _playerInputRef;
        private static PlayerInput PlayerInputRef
        {
            get
            {
                if (_playerInputRef == null)
                    _playerInputRef = Object.FindObjectOfType<PlayerInput>();

                return _playerInputRef;
            }
        }

        /// <summary>
        /// Sets a standard for keyboard and mouse name
        /// </summary>
        public static string KeyboardAndMouseName
        {
            get
            {
                return PlayerInputRef.currentActionMap.controlSchemes[0].name;
            }
        }

        /// <summary>
        /// Sets a standard for gamepad name
        /// </summary>
        public static string GamepadName
        {
            get
            {
                return PlayerInputRef.currentActionMap.controlSchemes[1].name;
            }
        }

        /// <summary>
        /// Get's the current control scheme
        /// </summary>
        public static string CurrentControlSchemeName
        {
            get
            {
                return PlayerInputRef.currentControlScheme.ToString();
            }
        }

        #endregion

        #region Bools
        /// <summary>
        /// Asks if controller connected
        /// </summary>
        /// <returns></returns>
        public static bool IsControllerControllerConnected()
        {
            return GamepadName == CurrentControlSchemeName;
        }
        #endregion
    }

}
