using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace V0_1 
{
    /// <summary>
    /// Used to detect the first change and switch to a thing whenever the input system changes
    /// </summary>
    public class GoBackToFirstSelected : MonoBehaviour
    {
        #region Data
        [Header("Input RElated")]

        [Tooltip("If input changed in the last frame")]
        [SerializeField, HideInInspector]
        private string _lastDeviceLogged;
        #endregion

        #region Unity Methods
        private void Update()
        {
            string currentDeviceLogged = GlobalStaticInput.CurrentControlSchemeName;

            if (currentDeviceLogged != _lastDeviceLogged &&
                GlobalStaticInput.IsControllerControllerConnected())
            {
                //TODO: Allow method to trigger whenever the controller is plugged in
                EventSystem.current.SetSelectedGameObject(EventSystem.current.firstSelectedGameObject);
            }

            _lastDeviceLogged = GlobalStaticInput.CurrentControlSchemeName;
        }
        #endregion
    }
}

