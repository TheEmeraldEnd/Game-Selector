using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GlobalScripts;
using System.Linq;
using System.Net.Http.Headers;

namespace GlobalScripts
{
    /// <summary>
    /// Used for more appolication specific methods in unity, does not use System.IO.
    ///     Refer to FileAccessorStatic for file reading
    /// </summary>
    public static class UnityFileAccessorStatic
    {
        #region Names
        /// <summary>
        /// Used to get access to the documents needed for this file
        /// </summary>
        private static string _documentDirectoryName = "Document";
        public static string DocumentDirectoryName
        {
            get
            {
                return _documentDirectoryName;
            }
        }

        /// <summary>
        /// Get's the application data path, Note: Does change when in builds
        /// </summary>
        private static string _applicationPath = Application.dataPath;
        public static string ApplicationPath
        {
            get
            {
                return _applicationPath;
            }
        }

        /// <summary>
        /// Get's the text file name of the game executables file
        /// </summary>
        private static string _gameExecutablesTextFile = "GameExecutablesPath.txt";
        public static string GameExecutablesTextFile
        {
            get { return _gameExecutablesTextFile; }
        }

        public static string CompleteGameExecutablesTextPath
        {
            get
            {
                return $"{ApplicationPath}\\{GameExecutablesTextFile}";
            }
        }
        #endregion

        /// <summary>
        /// Get's the file of a text file unless it doesn't exist, then it creates a new file
        ///
        /// </summary>
        /// <param name="textFileWithPath"></param>
        //! Note that it 
        public static void SetUpTextFile(string textFileWithPath)
        {
            if (!FileAccessorStatic.DoesFileExist(textFileWithPath))
            {
                FileAccessorStatic.CreateFile(textFileWithPath);
            }
        }

        /// <summary>
        /// Get's the entirety of the text of a text file
        /// </summary>
        /// <param name="textFileWithPath"></param>
        /// <returns></returns>
        public static string GetTextFileContent(string textFileWithPath)
        {
            return FileAccessorStatic.GetTextFileContentWhole(textFileWithPath);
        }

        /// <summary>
        /// Get's the contents of a text file per line
        /// </summary>
        /// <param name="textFileWithPath"></param>
        /// <returns></returns>
        public static string[] GetLinesFromTextFile(string textFileWithPath)
        {
            return FileAccessorStatic.GetTextFileContents(textFileWithPath);
        }

        /// <summary>
        /// Overwrites the contents to a text file
        /// </summary>
        /// <param name="textFileWithPath"></param>
        /// <param name="contents"></param>
        public static void WriteLinesToTextFile(string textFileWithPath, string[] contents)
        {
            string content = "";
            for(int i = 0; i < contents.Length; i++)
            {
                if (i == 0)
                    content = contents[i];
                else
                    content += "\n" + contents[i];
            }

            WriteToTextFile(textFileWithPath, content);
        }

        /// <summary>
        /// Overwrites the contents to a text file
        /// </summary>
        /// <param name="textFileWithPath"></param>
        /// <param name="contents"></param>
        public static void WriteToTextFile(string textFileWithPath, string content)
        {
            FileAccessorStatic.OverwriteToTextFile(textFileWithPath, content);
        }
    }
}

