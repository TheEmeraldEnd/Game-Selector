using System.IO;
using System.Linq;
using UnityEditor;

namespace GlobalScripts
{
    /// <summary>
    /// Used to access the space on disk and read files from disk
    /// </summary>
    public static class FileAccessorStatic
    {
        /// <summary>
        /// Checks if the file exists
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static bool DoesFileExist(string filePath)
        {
            return File.Exists(filePath);
        }

        /// <summary>
        /// Get's the contents of a file path if one exists, if one doesn't exist,
        ///     returns an array containing "No file path found"
        /// </summary>
        /// <param name="textFilePath"></param>
        /// <returns></returns>
        public static string[] GetTextFileContents(string textFilePath)
        {
            if (!DoesFileExist(textFilePath))
            {
                string[] errorMessage = { "No file path found" };
                return errorMessage;
            }

            return File.ReadAllLines(textFilePath); 
        }

        /// <summary>
        /// Get's the contents of a file path if one exists, if one doesn't exist,
        ///     returns an array containing "No file path found"
        /// </summary>
        /// <param name="textFilePath"></param>
        /// <returns></returns>
        public static string GetTextFileContentWhole(string textFilePath)
        {
            if (!DoesFileExist(textFilePath))
            {
                string errorMessage = "No file path found";
                return errorMessage;
            }

            return File.ReadAllText(textFilePath);
        }

        /// <summary>
        /// Allows creation of a file path, if it exists, overwrite
        /// </summary>
        /// <param name="filePath"></param>
        public static void CreateFile(string filePath)
        {
            File.Create(filePath);
        }

        /// <summary>
        /// Overwrites the text file contents of a specified text file, doesn't work if file doesn't exist
        /// </summary>
        /// <param name="textFileWithPath"></param>
        /// <param name="textFileContent"></param>
        public static void OverwriteToTextFile(string textFileWithPath, string textFileContent)
        {
            File.WriteAllText(textFileWithPath, textFileContent);
        }
    }
}